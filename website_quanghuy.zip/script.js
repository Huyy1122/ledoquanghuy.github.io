// Đổi slogan ngẫu nhiên
document.getElementById("changeSlogan").addEventListener("click", function() {
    const slogans = [
        "Học hỏi không ngừng, sáng tạo không giới hạn",
        "Code là cuộc sống, sáng tạo là đam mê",
        "Mỗi dòng code là một bước tiến mới",
        "Luôn tìm kiếm giải pháp tốt hơn"
    ];
    const randomSlogan = slogans[Math.floor(Math.random() * slogans.length)];
    document.getElementById("slogan").textContent = `"${randomSlogan}"`;
});

// Hiệu ứng fade-in khi cuộn
const fadeElements = document.querySelectorAll(".fade-in");
function checkFadeIn() {
    const triggerBottom = window.innerHeight * 0.85;
    fadeElements.forEach(el => {
        const rect = el.getBoundingClientRect();
        if (rect.top < triggerBottom) {
            el.classList.add("show");
        }
    });
}
window.addEventListener("scroll", checkFadeIn);
window.addEventListener("load", checkFadeIn);
